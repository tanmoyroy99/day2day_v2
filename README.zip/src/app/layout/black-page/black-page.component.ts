import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-black-page',
    templateUrl: './black-page.component.html',
    styleUrls: ['./black-page.component.scss']
})
export class BlackPageComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}
