import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-material-components',
    templateUrl: './material-components.component.html',
    styleUrls: ['./material-components.component.scss']
})
export class MaterialComponentsComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}
